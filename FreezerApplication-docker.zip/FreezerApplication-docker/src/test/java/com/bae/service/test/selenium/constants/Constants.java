package com.bae.service.test.selenium.constants;


public class Constants {

	public static final String PATH = "chromedriver";
	public static final String PROPERTY = "webdriver.chrome.driver";
	
	private Constants() {

	}

}
